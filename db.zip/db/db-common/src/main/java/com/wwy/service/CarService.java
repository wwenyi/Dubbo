package com.wwy.service;

import java.util.List;
import com.wwy.entry.Car;

public interface CarService {
List<Car> getAll();
}
